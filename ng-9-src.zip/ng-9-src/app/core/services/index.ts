/*
Developer Name: Vinay Kumar
File Modify By: Vinay Kumar
Date: Aug 29, 2020
TFS ID: 17214
Logic Description: added useraccess.service
Start Code
Line number 15
*/
export * from './auth.service';
export * from './json-api.service';
export * from './project.service';
export * from './api.service';
export * from './theme.service';
export * from './useraccess.service';
export * from './preferencetype.service';
/*TFS ID: 17214
 End Code*/
