"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceRole = void 0;
var ResourceRole = /** @class */ (function () {
    function ResourceRole() {
    }
    return ResourceRole;
}());
exports.ResourceRole = ResourceRole;
//# sourceMappingURL=resource-roles.js.map