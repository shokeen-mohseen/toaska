"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Organization = void 0;
var Organization = /** @class */ (function () {
    function Organization() {
        this.PageNo = 1;
        this.PageSize = 100;
        this.SortOrder = 'ASC';
    }
    return Organization;
}());
exports.Organization = Organization;
//# sourceMappingURL=organization.js.map