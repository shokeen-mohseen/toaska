"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpinnerObject = void 0;
var SpinnerObject = /** @class */ (function () {
    function SpinnerObject() {
    }
    return SpinnerObject;
}());
exports.SpinnerObject = SpinnerObject;
//# sourceMappingURL=SpinnerObject.model.js.map