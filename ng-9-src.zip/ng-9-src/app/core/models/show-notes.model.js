"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShowNotes = void 0;
var ShowNotes = /** @class */ (function () {
    function ShowNotes() {
        this.isEditableMode = false;
    }
    return ShowNotes;
}());
exports.ShowNotes = ShowNotes;
//# sourceMappingURL=show-notes.model.js.map