export class AlertSystem {
  username: string;
  userId: number;
  partographId: string;
  inputValue: string;
  alertMessageKey: string;
  alertTypeKey: string;
  actualTime: string;
  createdDate: Date;
  alertStatus: string;
}
