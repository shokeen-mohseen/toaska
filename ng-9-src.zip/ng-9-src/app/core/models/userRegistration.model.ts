import { Role } from "./role";

export class UserRegistration {
  id?: number;
  username: string;
  password: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  companytype?: string;
  code?: string;
  mobile?: string;

}
