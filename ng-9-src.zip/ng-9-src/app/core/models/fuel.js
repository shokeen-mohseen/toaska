"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FuelPriceViewModel = void 0;
var FuelPriceViewModel = /** @class */ (function () {
    function FuelPriceViewModel() {
        this.PageNo = 1;
        this.PageSize = 100;
        this.sourceSystemId = 1;
    }
    return FuelPriceViewModel;
}());
exports.FuelPriceViewModel = FuelPriceViewModel;
//# sourceMappingURL=fuel.js.map