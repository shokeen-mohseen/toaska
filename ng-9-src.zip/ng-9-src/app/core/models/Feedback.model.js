"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = exports.modelCommon = exports.Feedback = void 0;
var Feedback = /** @class */ (function () {
    function Feedback() {
    }
    return Feedback;
}());
exports.Feedback = Feedback;
var modelCommon = /** @class */ (function () {
    function modelCommon() {
    }
    return modelCommon;
}());
exports.modelCommon = modelCommon;
var UserModel = /** @class */ (function () {
    function UserModel() {
    }
    return UserModel;
}());
exports.UserModel = UserModel;
//# sourceMappingURL=Feedback.model.js.map