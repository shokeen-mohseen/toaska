export class ResourceRole {
  ClientID: number;
}
