export class SpinnerObject {
  status: boolean;
  source: string;
}
