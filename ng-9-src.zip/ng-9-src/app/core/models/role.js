"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Role;
(function (Role) {
    Role["User"] = "User";
    Role["Admin"] = "Admin";
})(Role = exports.Role || (exports.Role = {}));
//# sourceMappingURL=role.js.map