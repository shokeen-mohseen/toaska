export class PatientInfo {

  SearchMode: string;
  PatientId: number;
}
