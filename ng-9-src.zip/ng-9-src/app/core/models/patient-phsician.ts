

export class PhysicianPatient {

  Id: number;
  PatientId: number;
  ResourceId: number;
  ClientId: number;
  SourceSystemId: number;
  isPhysicianSelected: boolean= false;
  constructor() {
    

  }

}


